import firebase from "firebase"
const firebaseConfig = {
  apiKey: "AIzaSyDxZH1zBRsz824cJifJON2UB2du3J-BgHw",
  authDomain: "buzzer-app-b2b3a.firebaseapp.com",
  databaseURL:"https://buzzer-app-b2b3a-default-rtdb.firebaseio.com/",
  projectId: "buzzer-app-b2b3a",
  storageBucket: "buzzer-app-b2b3a.appspot.com",
  messagingSenderId: "562827508153",
  appId: "1:562827508153:web:bafa45146155d285631e68"
};
firebase.initializeApp(firebaseConfig);
export default firebase.database()